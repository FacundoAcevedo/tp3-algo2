#!/usr/bin/env python2
# -*- coding: utf-8 -*-

#Constantes
infinito = float("inf")
msj_mapa = "Ingrese la ubicacion del mapa:"
msj_pizeria = "Ingrese la direccion de la pizeria:"
msj_cliente = "Ingrese la direccion del cliente:"
msj_dijkstra = "Generando rutas, puede tardar..."
msj_kml = "Generando trazas..."
msj_kml_ok = "Generado correctamente, el archivo .kml"
msj_err_lugar = "El lugar de partida y el de destino, no deben ser el mismo!"
msj_cant_pedidos = "Se puede ingresar hasta 5 pedidos, cuandos quiere?"
